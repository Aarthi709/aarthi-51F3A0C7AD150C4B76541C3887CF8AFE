#1.1 Implement a recussive function to calculate tha factorial of a given number.
n = 23
fact = 1
 
for i in range(1, n+1):
    fact = fact * i
 
print("The factorial of 23 is : ", end="")
print(fact)